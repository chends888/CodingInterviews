'''
Rubric:
    | # Passing  |       |
    |   tests    | Grade |
    |--------------------|
    |   < 4      |  D    |
    |     4      |  C    |
    |     6      |  C+   |
    |     8      |  B    |
    |     10     |  B+   |
    |     12     |  A    |
    |     14     |  A+   |
'''

def pre_order_recursive(root):
    return []


def pre_order_iterative(root):
    return []


def in_order_recursive(root):
    return []


def in_order_iterative(root):
    return []


def post_order_recursive(root):
    return []


def post_order_iterative(root):
    return []


def breadth_first(root):
    return []
